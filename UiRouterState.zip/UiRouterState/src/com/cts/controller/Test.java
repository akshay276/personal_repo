package com.cts.controller;

public class Test {

	public static void main(String[] args) {
		int i = 0;
		// String s = "name";
		String ss = "java";
		String[] name = { "java", "json", "js" };
		String[] value = { "easy", "gandphaad", "padhna nahi" };
		for (int j = 0; j < name.length; j++) {

			System.out.print("{\"");
			System.out.print(name[j]);
			System.out.print("\":\"");
			System.out.print(value[j]);
			System.out.print("\"}");
			if(j<name.length-1){
			System.out.print(",");
			// {"name":"java"}
			}
			else{
				System.exit(1);
			}
		}
	}
}
