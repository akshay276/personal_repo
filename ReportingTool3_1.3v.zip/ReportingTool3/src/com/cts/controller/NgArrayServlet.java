package com.cts.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class NgArrayServlet
 */
public class NgArrayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public NgArrayServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// fetching data from session from NgServlet
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("user");
		System.out.println("Session get attribute:  " + user);

		// Username + arrays passed for json conversion
		String s = json.gsonToJson(user);
		System.out.println(s);
		System.out.println("LAST LINE OF SERVLET..." + s);

		// sending data to UI
		response.getWriter().write(s);
		response.setStatus(200);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
