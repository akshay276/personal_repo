package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.Users;
import com.cts.service.UserService;

public class NgServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public NgServlet() {
		System.out.println("Inside Servlet Constructor");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		boolean flag = false;
		String uname = request.getParameter("userName");
		String pwd = request.getParameter("passWord");
		String email = request.getParameter("emailId");
		int empId = Integer.parseInt(request.getParameter("empId"));

		System.out.println("values in doGet method: " + uname + pwd + email
				+ empId);
		Users users = new Users();
		users.setUsername(uname);
		users.setPassword(pwd);
		users.setEmail(email);
		users.setEmpId(empId);

		System.out.println("set'd all values into Users");
		UserService service = new UserService();
		try {
			flag = service.insertUserDetail(users);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (flag) {
			System.out.println("inside if condition servlet");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().write("User registered");

		} else {
			response.sendError(402);
			response.getWriter().write("User already present");
		}

		// ---------------//

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Inside POST Servlet");
		Users users = new Users();
		UserService service = new UserService();
		GsonToJson gj = new GsonToJson();
		boolean flag = false;
		String json = "";
		String uname = request.getParameter("userName");
		String pwd = request.getParameter("passWord");

		System.out.println("In Servlet- uname: " + uname + "  " + "pass: "
				+ pwd);

		users.setUsername(uname);
		users.setPassword(pwd);
		System.out
				.println("After setting pwd and Uname in Servlet:   " + users);

		try {
			flag = service.getUserDetails(users);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (flag == true) {
			System.out.println("Inside If condition of Servlet");
			System.out.println("Data in Users Now:- " + users.getUsername());
			json = gj.jsonConvertor(users);
			System.out.println(json);
			response.setContentType("application/json");

			// creating session to store User Details
			String user = users.getUsername();
			System.out.println("userrname in session first: " + user);
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			response.sendRedirect("NgArray");

			// sending data to UI
			response.getWriter().write(json);
			response.setStatus(200);

		} else {

			System.out.println("Inside else condition of Servlet");

			response.getWriter().write("Invalid Credentials");
			response.sendError(400);
		}

	}
}