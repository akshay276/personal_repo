package com.cts.controller;

import com.google.gson.Gson;

public class json {

	public static void main(String[] args) {
		String h = json.gsonToJson("admin");
		System.out.println(h);
	}

	public static String gsonToJson(String user) {

		String[] s = { "ACCOUNT DETAILS", "CHANGE PASSWORD", "REQUEST ACCESS", "HISTORY" };

		Gson gs = new Gson();
		String json = gs.toJson(s);
		System.out.println("FINAL JSON:" + json);
		return json;

	}

}
