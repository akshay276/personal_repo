package com.cts.controller;

import com.cts.model.Users;
import com.google.gson.Gson;

public class GsonToJson {

	public static String convertor() {

		Users m = new Users();
		Gson gson = new Gson();
		String json = gson.toJson(m);
		System.out.println(json);
		return json;

	}

}
