var app = angular.module("myApp", []);

app.controller('myAppCtrl', function($scope, $http, $log) {

	$scope.login = function() {
		window.location = "login.html";
	};

	$scope.register = function() {
		window.location = "register.html";
	};

	$scope.onSubmitLogin = function() {

		var _successCallback = function(data, status, headers) {
			$scope.Users = data;
			$log.info(data);
			window.location = "welcome.html";

		};

		var _errorCallback = function(data, status, headers) {
			$log.info(data);
			window.location = "error.html";

		};

		$http({

			method : 'POST',
			url : 'NgUser',
			params : {
				userName : $scope.userNameLogin,
				passWord : $scope.passWordLogin
			}
		}).then(_successCallback, _errorCallback);

	};

	$scope.onSubmitRegistration = function() {

		var _successEntry = function(data, status, headers) {
			$scope.Users = data;
			$log.info(data);
			window.location = "afterReg.html";
		}
		var _failedEntry = function(data, status, headers) {
			$scope.Users = data;
			$log.info(data);
			window.location = "afterError.html";
		}

		$http({

			method : 'GET',
			url : 'NgUser',
			params : {
				userName : $scope.userNameReg,
				passWord : $scope.passWordReg,
				emailId : $scope.emailReg,
				empId : $scope.empIdReg
			}

		}).then(_successEntry, _failedEntry)

	};

});